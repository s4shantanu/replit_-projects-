class Rectangle:
    def __init__(self, width: float, height: float):
        self.height = height
        self.width = width
    
    def set_width(self, width: float):
        """set width of rectangle"""
        self.width = width
    
    def set_height(self, height: float):
        """set height of rectangle"""
        self.height = height

    def get_area(self):
        """Returns area (width * height)"""
        return self.width * self.height

    def get_perimeter(self):
        """Returns perimeter (2 * width + 2 * height)"""
        return 2 * self.width + 2 * self.height

    def get_diagonal(self):
        """Returns diagonal ((width ** 2 + height ** 2) ** .5)"""
        return (self.width ** 2 + self.height ** 2) ** .5

    def __repr__(self):
        return f"Rectangle(width={self.width}, height={self.height})" 


class Square(Rectangle):
    def __init__(self, side: float):
        self.side = side
        super().__init__(side, side)

    def set_side(self, side: float):
        """set side length of the square"""
        self.side = side
        self.set_width = side
        self.set_height = side

    def __repr__(self):
        return f"Square(side={self.side})"
